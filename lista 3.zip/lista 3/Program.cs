﻿using System;

class Program {
    static void Main() {
        Console.Write("Primeiro número: ");
        double a = double.Parse(Console.ReadLine());
        Console.Write("Segundo número: ");
        double b = double.Parse(Console.ReadLine());

        Console.Write("Operação (+ - * /): ");
        char op = char.Parse(Console.ReadLine());

        double resultado = 0;
        bool valido = true;

        switch(op) {
            case '+': resultado = a + b; break;
            case '-': resultado = a - b; break;
            case '*': resultado = a * b; break;
            case '/':
                if (b != 0) resultado = a / b;
                else { Console.WriteLine("Divisão por zero não permitida."); valido = false; }
                break;
            default:
                Console.WriteLine("Operação inválida."); valido = false;
                break;
        }

        if (valido) Console.WriteLine($"Resultado: {resultado}");
    }
}
