using System;

class Program
{
    static void Main()
    {

        Q1.Executar();
        
        Q2.Executar();
        
        Q3.Executar();
        
        Q4.Executar();
        
        Q5.Executar();
        
        Q6.Executar();
        
        Q7.Executar();
        
        Q8.Executar();
        
        Q9.Executar();
        
        Q10.Executar();

    }
}
