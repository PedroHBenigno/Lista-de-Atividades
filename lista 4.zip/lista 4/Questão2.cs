using System;

class Questao2
{
    // Procedimento que lê salários e calcula média
    static void CalcularMediaSalario()
    {
        double soma = 0;
        int contador = 0;
        double[] salarios = new double[100]; // Vetor para armazenar salários

        while (true)
        {
            Console.Write("Digite o salário (ou -1 para encerrar): ");
            double salario = double.Parse(Console.ReadLine());

            if (salario == -1) break; // Flag de parada

            salarios[contador] = salario; // Armazena no vetor
            soma += salario; // Soma os salários
            contador++; // Incrementa o total de pessoas
        }

        if (contador > 0)
        {
            double media = soma / contador; // Calcula média
            Console.WriteLine($"Média salarial: {media:F2}");
        }
        else
        {
            Console.WriteLine("Nenhum dado informado.");
        }
    }

    public static void Executar()
    {
        CalcularMediaSalario();
    }
}
