using System;

class Questao4
{
    // Função que calcula o MDC pelo algoritmo de Euclides
    static int MDC(int a, int b)
    {
        while (b != 0)
        {
            int resto = a % b;
            a = b;
            b = resto;
        }
        return a;
    }

    public static void Executar()
    {
        Console.Write("Digite o primeiro número: ");
        int a = int.Parse(Console.ReadLine());
        Console.Write("Digite o segundo número: ");
        int b = int.Parse(Console.ReadLine());

        int resultado = MDC(a, b);
        Console.WriteLine($"MDC de {a} e {b} = {resultado}");
    }
}
