using System;

class Questao9
{
    static void CalcularDuracao(int hi, int mi, int hf, int mf, ref int horas, ref int minutos)
    {
        int inicio = hi * 60 + mi;
        int fim = hf * 60 + mf;

        if (fim < inicio)
            fim += 24 * 60;

        int duracao = fim - inicio;
        horas = duracao / 60;
        minutos = duracao % 60;
    }

    public static void Executar()
    {
        Console.Write("Hora inicial: ");
        int hi = int.Parse(Console.ReadLine());
        Console.Write("Minuto inicial: ");
        int mi = int.Parse(Console.ReadLine());
        Console.Write("Hora final: ");
        int hf = int.Parse(Console.ReadLine());
        Console.Write("Minuto final: ");
        int mf = int.Parse(Console.ReadLine());

        int horas = 0, minutos = 0;

        CalcularDuracao(hi, mi, hf, mf, ref horas, ref minutos);

        Console.WriteLine($"Duração: {horas}h {minutos}min");
    }
}
