using System;

class Questao7
{
    static double MediaAprovados(double[] notas)
    {
        double soma = 0;
        int cont = 0;

        for (int i = 0; i < notas.Length; i++)
        {
            if (notas[i] >= 6)
            {
                soma += notas[i];
                cont++;
            }
        }

        if (cont == 0) return 0;
        return soma / cont;
    }

    public static void Executar()
    {
        Console.Write("Digite o número de alunos: ");
        int n = int.Parse(Console.ReadLine());

        double[] notas = new double[n];

        for (int i = 0; i < n; i++)
        {
            Console.Write($"Digite a nota do aluno {i + 1}: ");
            notas[i] = double.Parse(Console.ReadLine());
        }

        double media = MediaAprovados(notas);
        Console.WriteLine($"Média dos aprovados: {media:F2}");
    }
}
