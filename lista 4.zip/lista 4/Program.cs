using System;

class Program
{
    // Método Main: ponto de entrada do programa
    public static void Main(string[] args)
    {
        // Mensagem pedindo ao usuário escolher a questão
        Console.WriteLine("Escolha a questão para testar (1 a 10): ");
        
        // Lê a entrada do usuário em uma string
        string? entrada = Console.ReadLine();
        
        // Variável para armazenar a opção convertida
        int opcao;
        
        // Tenta converter a entrada para inteiro; se falhar, define opcao = 0
        if (!int.TryParse(entrada, out opcao))
        {
            opcao = 0; // valor inválido
        }

        // Chama a questão correspondente com switch
        switch (opcao)
        {
            case 1: Questao1.Executar(); break;
            case 2: Questao2.Executar(); break; // caso você tenha os outros arquivos
            case 3: Questao3.Executar(); break;
            case 4: Questao4.Executar(); break;
            case 5: Questao5.Executar(); break;
            case 6: Questao6.Executar(); break;
            case 7: Questao7.Executar(); break;
            case 8: Questao8.Executar(); break;
            case 9: Questao9.Executar(); break;
            case 10: Questao10.Executar(); break;
            default:
                // Mensagem de opção inválida
                Console.WriteLine("Opção inválida. Execute novamente e digite um número entre 1 e 10.");
                break;
        }
    }
}
