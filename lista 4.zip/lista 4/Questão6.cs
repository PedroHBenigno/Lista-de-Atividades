using System;

class Questao6
{
    static void CalcularReajuste(double salario, double indice)
    {
        double novoSalario = salario + (salario * (indice / 100));
        Console.WriteLine($"Novo salário: R$ {novoSalario:F2}");
    }

    public static void Executar()
    {
        Console.Write("Digite o salário atual: ");
        double salario = double.Parse(Console.ReadLine());

        Console.Write("Digite o índice de reajuste (%): ");
        double indice = double.Parse(Console.ReadLine());

        CalcularReajuste(salario, indice);
    }
}
