using System;

class Questao3
{
    // Procedimento que verifica tipo de triângulo
    static void VerificarTriangulo(double x, double y, double z)
    {
        if (x < y + z && y < x + z && z < x + y)
        {
            if (x == y && y == z)
                Console.WriteLine("Triângulo Equilátero");
            else if (x == y || y == z || x == z)
                Console.WriteLine("Triângulo Isósceles");
            else
                Console.WriteLine("Triângulo Escaleno");
        }
        else
        {
            Console.WriteLine("Os valores não formam um triângulo.");
        }
    }

    public static void Executar()
    {
        double[] lados = new double[3]; // Vetor para armazenar os lados

        Console.Write("Digite o lado X: ");
        lados[0] = double.Parse(Console.ReadLine());
        Console.Write("Digite o lado Y: ");
        lados[1] = double.Parse(Console.ReadLine());
        Console.Write("Digite o lado Z: ");
        lados[2] = double.Parse(Console.ReadLine());

        VerificarTriangulo(lados[0], lados[1], lados[2]);
    }
}
