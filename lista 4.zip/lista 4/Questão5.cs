using System;

class Questao5
{
    // Função que verifica se número é positivo
    static bool Positivo(int n)
    {
        return n >= 0;
    }

    public static void Executar()
    {
        Console.Write("Quantos números deseja verificar? ");
        int qtd = int.Parse(Console.ReadLine());

        int[] numeros = new int[qtd];

        for (int i = 0; i < qtd; i++)
        {
            Console.Write($"Digite o {i + 1}º número: ");
            numeros[i] = int.Parse(Console.ReadLine());
        }

        for (int i = 0; i < qtd; i++)
        {
            if (Positivo(numeros[i]))
                Console.WriteLine($"{numeros[i]} é positivo.");
            else
                Console.WriteLine($"{numeros[i]} é negativo.");
        }
    }
}
