﻿using System;

class Questao1
{
    // Função que calcula a potenciação sem usar Math.Pow
    // Recebe a base (baseNum) e o expoente (expoente) e retorna int
    static int Potencia(int baseNum, int expoente)
    {
        int resultado = 1; // inicializa com 1 (qualquer número^0 = 1)

        // Se expoente for zero, o laço não roda e resultado = 1
        // Se expoente for negativo, este método não trata (pode ser estendido se necessário)
        for (int i = 0; i < expoente; i++) // repete 'expoente' vezes
        {
            resultado *= baseNum; // multiplica resultado pela base a cada iteração
        }

        return resultado; // retorna o valor calculado
    }

    // Método que executa a questão (será chamado pelo Program.Main)
    public static void Executar()
    {
        // Lê a base como string (Console.ReadLine pode retornar null)
        Console.Write("Digite a base (inteiro): ");
        string? sBase = Console.ReadLine();

        // Converte com TryParse para evitar exceção se a entrada for nula ou inválida
        int baseNum;
        if (!int.TryParse(sBase, out baseNum))
        {
            // Se falhar, avisa e encerra a execução da questão
            Console.WriteLine("Entrada inválida para a base. Use um número inteiro.");
            return;
        }

        // Lê o expoente como string
        Console.Write("Digite o expoente (inteiro >= 0): ");
        string? sExpo = Console.ReadLine();

        // Converte com TryParse
        int expoente;
        if (!int.TryParse(sExpo, out expoente))
        {
            // Se falhar, avisa e encerra
            Console.WriteLine("Entrada inválida para o expoente. Use um número inteiro.");
            return;
        }

        // Checagem simples: expoente negativo não tratado por essa implementação
        if (expoente < 0)
        {
            Console.WriteLine("Expoente negativo não suportado por esta implementação.");
            return;
        }

        // Chama a função Potencia e captura o resultado
        int resultado = Potencia(baseNum, expoente);

        // Exibe o resultado formatado
        Console.WriteLine($"Resultado: {baseNum}^{expoente} = {resultado}");
    }
}
