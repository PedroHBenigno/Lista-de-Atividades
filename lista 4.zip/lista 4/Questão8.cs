using System;

class Questao8
{
    static bool Primo(int n)
    {
        if (n < 2) return false;
        for (int i = 2; i <= n / 2; i++)
        {
            if (n % i == 0) return false;
        }
        return true;
    }

    public static void Executar()
    {
        Console.Write("Digite um número: ");
        int n = int.Parse(Console.ReadLine());

        if (Primo(n))
            Console.WriteLine($"{n} é primo.");
        else
            Console.WriteLine($"{n} não é primo.");
    }
}
