using System;

class Questao10
{
    static char Conceito(double media)
    {
        if (media < 5) return 'D';
        else if (media < 7) return 'C';
        else if (media < 9) return 'B';
        else return 'A';
    }

    public static void Executar()
    {
        Console.Write("Digite a média final do aluno: ");
        double media = double.Parse(Console.ReadLine());

        Console.WriteLine($"Conceito: {Conceito(media)}");
    }
}
